﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core.Interfaces;
using Core.CoreService;
namespace Core.Factory
{
    public class CommonFactory : ICommonFactory
    {
        public IUser Users()
        {
            return new User();
        }

        public IService Services()
        {
            return new Service();
        }

        public IUser Students()
        {
            return new Student();
        }
    }
}
