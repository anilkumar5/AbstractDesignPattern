﻿using Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.CoreService
{
    public class Service : IService
    {

        public string GetServiceName()
        {
            return "Service";
        }

        public string GetServiceAddress()
        {
            return "Ludhiana, punjab/India";
        }
    }
}
